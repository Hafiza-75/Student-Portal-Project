from django.contrib import admin
from django.urls import path
from django.http import HttpResponse

# 3 views/pages defined here:

def home(request):
    return HttpResponse("<h1>🎓 Welcome to the Student Portal</h1>")

def courses(request):
    return HttpResponse("<h2>📚 Courses Offered:<br>- Python<br>- Web Development<br>- Data Science</h2>")

def profile(request):
    return HttpResponse("<h2>👤 Student Profile<br>Name: Ameer Hamza<br>Program: BS Computer Science</h2>")

# URL patterns
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home),              # Root route (homepage)
    path('courses/', courses),   # Second root
    path('profile/', profile),   # Third root
]
